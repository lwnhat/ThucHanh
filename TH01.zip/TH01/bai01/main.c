#include <stdio.h>
#include <stdlib.h>

/* B�i 1. Hay in ra man hinh cac dong
a.Chao c�c ban
b.Ch�o		cac		ban
c.Ch�o
cac
ban */

int main(int argc, char *argv[]) {
/*a*/
//	printf("Chao cac ban");
/*b*/
//printf("Chao\tcac\tban");
/*c*/
printf("Chao\ncac\nban");
	return 0;
}
